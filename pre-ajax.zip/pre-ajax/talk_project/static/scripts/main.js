$(function() {

// nothing

console.log("nothing")

});